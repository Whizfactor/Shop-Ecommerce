export const environment = {
  production: true,
  apiUrl: 'https://whizfactor2.pythonanywhere.com/api/'
};
